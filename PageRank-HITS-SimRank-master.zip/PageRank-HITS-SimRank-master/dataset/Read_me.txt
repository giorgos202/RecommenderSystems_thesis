Each row represents a directed edge (link) between nodes separated by a comma.
The direction of a edge is from the first node to the second node.

graph_1.txt: 6 nodes, 5 edges
graph_2.txt: 5 nodes, 5 edges (a circle)
graph_3.txt: 4 nodes, 6 edges
graph_4.txt: 7 nodes, 18 edges (the example in Lecture3, p29)
graph_5.txt:  469 nodes, 1102 edges
graph_6.txt: 1228 nodes, 5220 edges
